package com.example.dachieu.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class MainActivity extends AppCompatActivity {
    private static String DN ="";
    Button btnClick;
    TextView txtThongTin,txtLoi;
    ImageView imgHinh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnClick=(Button)findViewById(R.id.btnClick);
        imgHinh=(ImageView)findViewById(R.id.imageHinh);
        txtThongTin=(TextView)findViewById(R.id.txtThongTin);
        txtLoi=(TextView)findViewById(R.id.txtLoi);

        final IntentIntegrator intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.initiateScan();
        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtThongTin.setText("");
                txtLoi.setText("");
                imgHinh.setImageResource(0);

                intentIntegrator.initiateScan();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(result != null) {
            if(result.getContents() == null) {
                Toast.makeText(this, "Hủy bỏ", Toast.LENGTH_LONG).show();
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(result.getContents());
                    String Data;
                    DN = jsonObject.getString("DN").trim();
                    Data = jsonObject.getString("Data").trim();
                    new PostToServer(Data).execute(DN+"/api/kiemtra");
                } catch (Exception e) {
                    txtLoi.setText("Mã QR không phải sản phẩm của hãng, hãy thử lại!");
                    e.printStackTrace();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    class PostToServer extends AsyncTask<String,Void,String>{
        OkHttpClient okHttpClient = new OkHttpClient.Builder().build();
        String Data;

        public PostToServer(String Data){
            this.Data = Data;
        }
        @Override
        protected String doInBackground(String... strings) {
            RequestBody requestBody = new MultipartBody.Builder()
                    .addFormDataPart("Data",Data)
                    .setType(MultipartBody.FORM)
                    .build();
            Request request = new Request.Builder()
                    .url(strings[0])
                    .post(requestBody)
                    .build();
            try {
                Response response = okHttpClient.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject jsonObject = new JSONObject(s);
                String TenSP, NhaSX, HinhAnh, urlHinhAnh,SDK, MaLo, NSX, HSD, TenDL, Data;

                // In Hình Ảnh
                HinhAnh = jsonObject.getString("HinhAnh").trim();
                urlHinhAnh = DN+"/upload/sanpham/"+HinhAnh;
                Picasso.get().load(urlHinhAnh).into(imgHinh);

                // In thông tin
                TenSP = jsonObject.getString("TenSP").trim().toUpperCase();
                NhaSX = jsonObject.getString(("NhaSX")).trim();
                SDK = jsonObject.getString("SDK").trim();
                MaLo = jsonObject.getString("MaLo").trim();
                NSX = jsonObject.getString("NSX").trim();
                HSD = jsonObject.getString("HSD").trim();
                TenDL = jsonObject.getString("TenDL").trim();
                Data = "Sản Phẩm:           " + TenSP + "\n\n"
                        + "Sản Xuất Bởi:        " + NhaSX + "\n"
                        + "Số Đăng Ký:          " + SDK + "\n"
                        + "Mã Lô Hàng:          " + MaLo + "\n"
                        + "NSX:                 " + NSX + "\n"
                        + "HSD:                 " + HSD + "\n"
                        + "Tên Đại Lý:          " + TenDL + "\n";
                txtThongTin.setText(Data);
            } catch (JSONException e) {
                txtLoi.setText(s);
                e.printStackTrace();
            }

            super.onPostExecute(s);
        }
    }
}
